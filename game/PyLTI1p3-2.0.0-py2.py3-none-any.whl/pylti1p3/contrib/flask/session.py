from pylti1p3.session import SessionService


class FlaskSessionService(SessionService):
    pass
