from pylti1p3.session import SessionService


class DjangoSessionService(SessionService):
    pass
