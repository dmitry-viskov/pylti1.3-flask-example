import typing_extensions as te


class Action:
    OIDC_LOGIN: te.Final = "oidc_login"
    MESSAGE_LAUNCH: te.Final = "message_launch"
